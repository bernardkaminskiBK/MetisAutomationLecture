import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome - Testing using JUnit 5 !!!");

        System.out.println(new CollectionsUtils().sortStrings(List.of("Eva", "Adam")));
    }
}
