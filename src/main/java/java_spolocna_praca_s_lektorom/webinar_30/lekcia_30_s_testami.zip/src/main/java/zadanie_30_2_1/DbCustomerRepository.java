package zadanie_30_2_1;

public class DbCustomerRepository implements CustomerRepository
{
    @Override
    public void save(final Customer customer)
    {
        try
        {
            Thread.sleep(5000);
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }

        // db.execute("insert into customer(first_name, last_name)
        // values(" + customer.getFirstName() + "," + customer.getLastName() ");")
    }

}
