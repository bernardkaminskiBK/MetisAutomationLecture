package zadanie_30_2_1;

public interface CustomerRepository
{
    void save(Customer customer);
}
