package zadanie_30_2_1;

public class Main
{
    public static void main(String[] args)
    {
        System.out.println("Welcome - Testing using JUnit 5 !!!");

        new CustomerService(new DbCustomerRepository()).savedCustomer(new Customer("Peter", "Vasil"));
    }
}
