package zadanie_30_2_1;

public class Calculator
{
    public int sum(int number1, int number2)
    {
        return number1 + number2;
    }
}
