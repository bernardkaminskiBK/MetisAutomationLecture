package zadanie_30_2_1;

public interface NumbersGenerator
{
    int generate();
}
