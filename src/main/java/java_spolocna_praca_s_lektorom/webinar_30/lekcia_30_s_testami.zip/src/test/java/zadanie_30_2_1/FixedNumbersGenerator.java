package zadanie_30_2_1;

import zadanie_30_2_1.NumbersGenerator;

/**
 * Always generate number
 */
public class FixedNumbersGenerator implements NumbersGenerator
{
    @Override
    public int generate()
    {
        return 5;
    }
}
